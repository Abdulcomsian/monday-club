{{-- <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <p class="mb-0">&copy; {{ date('Y') }} Your Company. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer> --}}